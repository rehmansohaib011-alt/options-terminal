# T.W.S GAMMA TERMINAL — Trade With Sohaib

A Streamlit app for options gamma exposure estimates, TradingView charts, unusual-volume scanning, watchlists, quote snapshots, and ticker-related news.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   streamlit run app.py
   ```
5. Open the local URL Streamlit prints (normally `http://localhost:8501`).

## Deploy free with Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt` to the repository root.
3. Go to https://share.streamlit.io/ and sign in with GitHub.
4. Create an app, choose your repository, branch, and `app.py` as the main file.
5. Deploy and wait for the build to finish.

## Data and limitations

- Public market/options data is retrieved through Yahoo Finance and Cboe delayed-options endpoints; access and coverage can vary by symbol and region.
- TradingView chart widgets require an internet connection and are provided by TradingView.
- Data may be delayed or incomplete. GEX is an estimate, not exchange-confirmed dealer positioning. The sign convention assumes calls positive and puts negative, so it is a simplified model rather than a statement of actual dealer inventory.
- Some crypto symbols have quotes and charts but do not have a supported listed-options chain in the current gamma module. Use an optionable equity/ETF (for example SPY, QQQ, or NVDA) for the Gamma view.
- This tool is for research/education, not financial advice.
